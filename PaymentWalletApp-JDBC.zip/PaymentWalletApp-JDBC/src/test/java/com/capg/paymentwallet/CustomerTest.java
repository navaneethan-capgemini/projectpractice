package com.capg.paymentwallet;

import com.capgemini.paymentwallet.bean.Customer;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {

	
	Customer c = new Customer();
	
	public void testGetCustName() {
		
		c.setCustomerName("Navaneethan");
		assertEquals("Navaneethan", c.getCustomerName());
	}

	public void testGetAge() {
		
		c.setAge(15);
		assertEquals(15, c.getAge());
	}

	public void testGetGender() {
		
		c.setGender("Male");
		assertEquals("Male", c.getGender());
	}

	public void testGetCustMobileNo() {
		
		c.setCustMobileNo("9940509549");
		assertEquals("9940509549", c.getCustMobileNo());
	}

	public void testGetCustAddress() {
		
		c.setCustAddress("Hyderabad");
		assertEquals("Hyderabad", c.getCustAddress());
	}

	public void testGetCustEmail() {
		c.setCustEmail("navaneethan10@gmail.com");
		assertEquals("navaneethan10@gmail.com", c.getCustEmail());
	}

	public void testGetuName() {
		
		c.setuName("Nav123");
		assertEquals("Nav123", c.getuName());
	}

	public void testGetuPassword() {
		
		c.setuPassword("12345678");
		assertEquals("12345678", c.getuPassword());
	}

}
