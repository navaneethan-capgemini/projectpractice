package com.capgemini.paymentwallet.bean;

public class Customer {

	private String customerName;
	private int age;
	private String gender;
	private String customerMobileNo;
	private String customerAddress;
	private String customerEmail;
	private String uName;
	private String uPassword;

	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCustMobileNo() {
		return customerMobileNo;
	}

	public void setCustMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}

	public String getCustAddress() {
		return customerAddress;
	}

	public void setCustAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustEmail() {
		return customerEmail;
	}

	public void setCustEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getuPassword() {
		return uPassword;
	}

	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", age=" + age + ", gender=" + gender + ", customerMobileNo="
				+ customerMobileNo + ", customerAddress=" + customerAddress + ", customerEmail=" + customerEmail
				+ ", uName=" + uName + ", uPassword=" + uPassword + "]";
	}

	
}
