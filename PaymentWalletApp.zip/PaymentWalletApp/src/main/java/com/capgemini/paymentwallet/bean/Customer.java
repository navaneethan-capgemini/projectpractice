package com.capgemini.paymentwallet.bean;

public class Customer {

	
	private String customerName;
	private int age;
	private String gender;
	private String customerMobileNo;
	private String customerAddress;
	private String customerEmail;
	private String userName;
	private String userPwd;
	private Wallet wallet;
		public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	@Override
	public String toString() {
		return "Customer [ customerName=" + customerName + ", age=" + age
				+ ", gender=" + gender + ", customerMobileNo=" + customerMobileNo + ", customerAddress="
				+ customerAddress + ", customerEmail=" + customerEmail + ", userName=" + userName + ", userPwd="
				+ userPwd + ", wallet=" + wallet + "]";
	}
	
	}

	
	


