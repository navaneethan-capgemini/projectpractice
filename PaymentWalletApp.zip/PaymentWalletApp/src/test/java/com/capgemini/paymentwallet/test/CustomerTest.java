package com.capgemini.paymentwallet.test;

import com.capgemini.paymentwallet.bean.Customer;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {

	
	Customer c = new Customer();
	
	

	public void testGetCustName() {
		
		c.setCustomerName("Navaneethan");
		assertEquals("Navaneethan", c.getCustomerName());
	}

	public void testGetAge() {
		
		c.setAge(15);
		assertEquals(15, c.getAge());
	}

	public void testGetGender() {
		
		c.setGender("Male");
		assertEquals("Male", c.getGender());
	}

	public void testGetCustMobileNo() {
		
		c.setCustomerMobileNo("9940509549");
		assertEquals("9940509549", c.getCustomerMobileNo());
	}

	public void testGetCustAddress() {
		
		c.setCustomerAddress("Hyderabad");
		assertEquals("Hyderabad", c.getCustomerAddress());
	}

	public void testGetCustEmail() {
		c.setCustomerEmail("navaneethan10@gmail.com");
		assertEquals("navaneethan10@gmail.com", c.getCustomerEmail());
	}

	public void testGetuName() {
		
		c.setUserName("Nav123");
		assertEquals("Nav123", c.getUserName());
	}

	public void testGetuPassword() {
		
		c.setUserPwd("12345678");
		assertEquals("12345678", c.getUserPwd());
	}

}
